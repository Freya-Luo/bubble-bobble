#include <iostream>
#include "simplebitmap.h"
#include "fssimplewindow.h"


void show(){
	float  player_x, player_y;
    SimpleBitmap bmp;
    bmp.LoadPng("../final_project/png/level1_s.png");
	FsOpenWindow(0,0,bmp.GetWidth(),bmp.GetHeight(),1);
	
	SimpleBitmap black = bmp.CutOut(100, 100, 1, 1);


	bool rising = false;
	bool walk1, walk2;
	int dir = 0; //0 is right, 1 is left;
	walk1 = false;
	walk2 = false;

	int j_cnt, f_cnt = 0;

	player_x = 100;
	player_y = 440;

	for(;;)
	{
		FsPollDevice();
		auto key=FsInkey();

    	SimpleBitmap player_bmp;
		if(FSKEY_ESC==key)
		{
			break;
		}

		if(FSKEY_LEFT==key)
		{
			player_x -= 10;
			dir = 1;
		}else if(FSKEY_RIGHT==key)
		{
			dir = 0;
			player_x += 10;
			if(walk1 == false){
				walk1 = true;
				walk2 = false;
			}else{
				walk2 = true;
				walk1 = false;
			}
		}

		if(FSKEY_UP==key)
		{
			if(j_cnt == 0 && f_cnt == 0){
				j_cnt = 1200;
				f_cnt = 1200;
			}
		}


		if(j_cnt > 0){
			rising = true;
			player_y -= 0.1;
			j_cnt -= 1;
		}
		if(f_cnt > 0 && j_cnt == 0){
			rising = false;
			player_y += 0.1;
			f_cnt -= 1;
		}

		if(player_x > bmp.GetWidth()-20){
			player_x = bmp.GetWidth()-20;	
		}
		if(player_x < 20){
			player_x = 20;
		}
		
		if(player_y < 20){
			player_y = 20;	
		}

		SimpleBitmap player_loc = bmp.CutOut(int(player_x)+16, int(player_y)+32, 1, 1);
		if(black.operator==(player_loc) && (!rising)){
			player_y += 0.2;
			f_cnt = 0;
		}

		if(dir == 0){
			if(!(walk1 || walk2)){
				player_bmp.LoadPng("../final_project/png/Bubble.png");
			}else if(walk1){
				player_bmp.LoadPng("../final_project/png/Bubble_walk1.png");
			}else{
				player_bmp.LoadPng("../final_project/png/Bubble_walk2.png");
			}
		}else{
			player_bmp.LoadPng("../final_project/png/Bubble_left.png");
		}
		

		glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
		glRasterPos2i(0, 0);
		glDrawPixels(bmp.GetWidth(),bmp.GetHeight(),GL_RGBA,GL_UNSIGNED_BYTE,bmp.GetBitmapPointer());
		
		
		glRasterPos2i(int(player_x), int(player_y));
		glDrawPixels(player_bmp.GetWidth(),player_bmp.GetHeight(),GL_RGBA,GL_UNSIGNED_BYTE,player_bmp.GetBitmapPointer());
		

		glPixelZoom(1.0,-1.0);
		FsSwapBuffers();
		
	}

}



int main(int argc,char *argv[]){
    show();
    return 0;
}