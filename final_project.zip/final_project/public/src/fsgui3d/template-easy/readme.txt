This template demonstrates a polling-based programming with FS-GUI library.

It allows the program to use FsGuiPopUpMenu and FsGuiDialog directly without creating a sub-class.

This example cannot be extended to an environment in which the API does not give control of the main-loop such as iOS.

