//
//  main.m
//  arucoMarkerDetection
//
//  Created by Soji Yamakawa on 2017/03/23.
//  Copyright © 2017年 ysflight.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
