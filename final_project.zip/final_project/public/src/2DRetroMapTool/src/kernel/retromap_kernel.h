#ifndef RETROMAP_KERNEL_IS_INCLUDED
#define RETROMAP_KERNEL_IS_INCLUDED
/* { */
/* } */
#endif
