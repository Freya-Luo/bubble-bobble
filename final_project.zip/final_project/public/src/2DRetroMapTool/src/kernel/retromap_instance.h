#ifndef RETROMAP_INSTANCE_IS_INCLUDED
#define RETROMAP_INSTANCE_IS_INCLUDED
/* { */
/* } */
#endif
