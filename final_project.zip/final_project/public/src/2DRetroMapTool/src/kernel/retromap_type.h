#ifndef RETROMAP_TYPE_IS_INCLUDED
#define RETROMAP_TYPE_IS_INCLUDED
/* { */
/* } */
#endif
