#ifndef GUN_IS_INCLUDED
#define GUN_IS_INCLUDED
/* { */

extern const unsigned long long sizeof_gun;
extern const unsigned char gun[];

/* } */
#endif
