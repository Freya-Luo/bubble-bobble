#ifndef PROP9_IS_INCLUDED
#define PROP9_IS_INCLUDED
/* { */

extern const unsigned long long sizeof_prop9;
extern const unsigned char prop9[];

/* } */
#endif
